-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2025 at 02:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farm_animal`
--

-- --------------------------------------------------------

--
-- Table structure for table `animals`
--

CREATE TABLE `animals` (
  `animal_id` int(11) NOT NULL,
  `animal_name` varchar(50) NOT NULL,
  `animal_instruction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `animals`
--

INSERT INTO `animals` (`animal_id`, `animal_name`, `animal_instruction`) VALUES
(6, 'Pig', 'Twice a day'),
(7, 'Chicken', 'Thrice a day'),
(8, 'Cow', 'Grass backyard'),
(9, 'Sheep', 'Twice and a half'),
(10, 'Ox', 'Twice a day');

-- --------------------------------------------------------

--
-- Table structure for table `feeding_log`
--

CREATE TABLE `feeding_log` (
  `feedlog_id` int(11) NOT NULL,
  `feed_name` varchar(50) NOT NULL,
  `feed_weight` int(11) NOT NULL,
  `feed_cost` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `log_date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feeding_log`
--

INSERT INTO `feeding_log` (`feedlog_id`, `feed_name`, `feed_weight`, `feed_cost`, `animal_id`, `inventory_id`, `log_date`) VALUES
(31, 'BMEG 11', 10, 100, 6, 6, '2025-05-30'),
(32, 'Grass', 20, 100, 8, 8, '2025-05-30'),
(33, 'Corn', 10, 10, 7, 7, '2025-05-30'),
(34, 'BMEG 12', 10, 10, 9, 9, '2025-05-30'),
(35, 'BMEG 77', 10, 10, 10, 10, '2025-05-29');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `feed_name` varchar(50) NOT NULL,
  `feed_cost` int(11) NOT NULL,
  `feed_weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `animal_id`, `feed_name`, `feed_cost`, `feed_weight`) VALUES
(6, 6, 'BMEG 11', 900, 90),
(7, 7, 'Corn', 90, 90),
(8, 8, 'Grass', 900, 180),
(9, 9, 'BMEG 12', 90, 90),
(10, 10, 'BMEG 77', 90, 90);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `sched_id` int(11) NOT NULL,
  `animal_name` int(11) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`sched_id`, `animal_name`, `time`) VALUES
(8, 6, '06:00:00'),
(9, 7, '07:00:00'),
(10, 8, '07:00:00'),
(11, 9, '03:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, '0', '123', 'riki@gmail.com'),
(2, 'asd', 'asd', 'asd'),
(4, 'addd', 'sdasddd', 'ddd'),
(5, 'sankiss', 'sankiss', 'sankiss@gmail.com'),
(6, 'ricky', '123', 'ricky@gmail.com'),
(7, 'Choi', '123', 'choi@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`animal_id`);

--
-- Indexes for table `feeding_log`
--
ALTER TABLE `feeding_log`
  ADD PRIMARY KEY (`feedlog_id`),
  ADD KEY `inventory_id` (`inventory_id`),
  ADD KEY `animal_id` (`animal_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `animal_id` (`animal_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`sched_id`),
  ADD KEY `animal_name` (`animal_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `animals`
--
ALTER TABLE `animals`
  MODIFY `animal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `feeding_log`
--
ALTER TABLE `feeding_log`
  MODIFY `feedlog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `sched_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feeding_log`
--
ALTER TABLE `feeding_log`
  ADD CONSTRAINT `feeding_log_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`),
  ADD CONSTRAINT `feeding_log_ibfk_2` FOREIGN KEY (`animal_id`) REFERENCES `animals` (`animal_id`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`animal_id`) REFERENCES `animals` (`animal_id`);

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`animal_name`) REFERENCES `animals` (`animal_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
